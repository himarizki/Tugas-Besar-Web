	<footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; Sekolah Oemah Codinger. All Rights Reserved.
                </div>
                
            </div>
        </div>
    </footer>