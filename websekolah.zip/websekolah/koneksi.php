<?php

    $host = "localhost";
    $username = "root";
    $pass = "";
    $db = "dbwebsekolah";

    $koneksi = mysqli_connect($host, $username, $pass, $db) or die ("tidak dapat terhubung kedatabase");

?>